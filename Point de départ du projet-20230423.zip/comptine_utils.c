#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include "comptine_utils.h"

int read_until_nl(int fd, char *buf)
{
	/* À définir */
	return 0;
}

int est_nom_fichier_comptine(char *nom_fich)
{
	/* À définir */
	return 0;
}

struct comptine *init_cpt_depuis_fichier(const char *dir_name, const char *base_name)
{
	/* À définir */
	return NULL;
}

void liberer_comptine(struct comptine *cpt)
{
	/* À définir */
}

struct catalogue *creer_catalogue(const char *dir_name)
{
	/* À définir */
	return NULL;
}

void liberer_catalogue(struct catalogue *c)
{
	/* À définir */
}
